import"./modulepreload-polyfill-B5Qt9EMX.js";import"./EntryFile-B3Dtvsvp.js";const e=()=>{r()},r=()=>{document.querySelector(".revenue-card").querySelector("h6").innerHTML="16"};e();
