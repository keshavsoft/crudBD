import"./EntryFile-De4oQfi8.js";const e=()=>{r()},r=()=>{document.querySelector(".revenue-card").querySelector("h6").innerHTML="16"};e();
