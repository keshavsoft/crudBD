(function(n){typeof define=="function"&&define.amd?define(n):n()})(function(){"use strict"});
