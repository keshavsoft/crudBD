import { StartFunc as StartFuncLoginButtonId } from "./LoginButtonId/EntryFile.js";

let StartFunc = ({ inSuccessFunc }) => {
    StartFuncLoginButtonId({ inSuccessFunc });
};

export { StartFunc };